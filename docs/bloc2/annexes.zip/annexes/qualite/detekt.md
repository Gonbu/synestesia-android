# detekt

## Metrics

* 236 number of properties

* 113 number of functions

* 14 number of classes

* 8 number of packages

* 35 number of kt files

## Complexity Report

* 3,591 lines of code (loc)

* 3,040 source lines of code (sloc)

* 2,135 logical lines of code (lloc)

* 257 comment lines of code (cloc)

* 292 cyclomatic complexity (mcc)

* 318 cognitive complexity

* 0 number of total code smells

* 8% comment source ratio

* 136 mcc per 1,000 lloc

* 0 code smells per 1,000 lloc

## Findings (0)

generated with [detekt version 1.23.5](https://detekt.dev/) on 2025-08-22 19:08:55 UTC
